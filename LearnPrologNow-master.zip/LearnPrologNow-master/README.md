# My answers for Learn Prolog Now!

At first I put my answers to the Learn Prolog Now! exercises in a zip file
and linked it from my blog... but then I thought, "Hey I'll put them on
GitHub!"
